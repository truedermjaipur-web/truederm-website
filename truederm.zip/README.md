# Truederm Jaipur — Premium Dermatology Website

A complete static website for **Truederm Jaipur** — Dr. Iftekhar Khan's advanced dermatology clinic.

---

## 📁 Folder Structure

```
truederm-jaipur/
├── index.html      ← Main website (all sections)
├── style.css       ← Complete styling
├── script.js       ← Animations, nav, form logic
└── README.md       ← This file
```

---

## 🚀 How to Deploy for FREE

### Option 1 — Netlify (Recommended, easiest)

1. Go to [netlify.com](https://netlify.com) and sign up (free)
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag and drop the entire `truederm-jaipur` folder onto Netlify
4. Your site is live instantly at a `.netlify.app` URL
5. To connect your GoDaddy domain:
   - In Netlify: Site Settings → Domain Management → Add custom domain
   - In GoDaddy DNS: Add Netlify's nameservers OR a CNAME record pointing to your Netlify URL
   - Netlify auto-provisions a free SSL certificate (HTTPS)

### Option 2 — GitHub Pages

1. Create a free account at [github.com](https://github.com)
2. Create a new repository named `truederm-jaipur` (public)
3. Upload all 3 files (index.html, style.css, script.js)
4. Go to: Settings → Pages → Source: **main branch, / (root)** → Save
5. Site goes live at `https://yourusername.github.io/truederm-jaipur`
6. To connect your GoDaddy domain:
   - In GitHub Pages settings: add your custom domain
   - In GoDaddy DNS: add a CNAME record: `www → yourusername.github.io`
   - Add A records pointing to GitHub Pages IPs

---

## 🖼️ Replacing Placeholder Images

The website uses styled placeholder areas where you should insert real photos:

| Placeholder | What to add | Recommended size |
|-------------|-------------|------------------|
| Hero doctor frame | Dr. Khan's photo | 720×900px |
| About doctor | Professional clinic/doctor photo | 760×960px |
| Results Before/After | Patient treatment photos | 400×300px each |

**To add images**, replace the `<div class="hero__img-placeholder">` divs with:
```html
<img src="images/doctor.jpg" alt="Dr. Iftekhar Khan" style="width:100%; height:100%; object-fit:cover;" />
```

Create an `images/` folder and place your photos there.

---

## 📞 Contact Details Already Set

- **Phone**: +91 70422 17716
- **WhatsApp**: +91 70422 17716
- **Instagram**: @truederm.jaipur
- **Address**: Bagadiya Bhawan, J-26 (First Floor), Subhash Marg, C-Scheme, Jaipur – 302001

---

## ✏️ Customizing Content

All content is in `index.html`. Search for these placeholders to update:

- Services: in the `#services` section
- Reviews: in the `#reviews` section (replace sample testimonials with real ones)
- Map: update the Google Maps embed URL in `#contact` with your actual location
- Instagram link: search for `truederm.jaipur` to update all links

---

## 🎨 Design Notes

- **Fonts**: Cormorant Garamond (display) + DM Sans (body) — loaded from Google Fonts
- **Colors**: Deep teal (#0a7372) + ivory white + gold accent (#c9a84c)
- **Animations**: CSS-only scroll reveal, floating cards, hover states
- **Mobile**: Fully responsive down to 320px width

---

## ⚠️ Before Going Live

1. Replace all placeholder images with real photos
2. Update the Google Maps embed to your exact address
3. Test the WhatsApp link with your actual phone number
4. Get patient consent before using any before/after photos
5. Review all content for accuracy

---

Built for Dr. Iftekhar Khan, MD Dermatology · Truederm Jaipur
