/* ============================================
   TRUEDERM JAIPUR — Main JavaScript
   ============================================ */

// ── NAVBAR SCROLL ──────────────────────────
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}, { passive: true });

// ── MOBILE HAMBURGER ────────────────────────
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('open');
  // Animate hamburger spans
  const spans = hamburger.querySelectorAll('span');
  if (navLinks.classList.contains('open')) {
    spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
    spans[1].style.opacity = '0';
    spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
  } else {
    spans[0].style.transform = '';
    spans[1].style.opacity = '';
    spans[2].style.transform = '';
  }
});

// Close nav on link click (mobile)
document.querySelectorAll('.nav__links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    const spans = hamburger.querySelectorAll('span');
    spans[0].style.transform = '';
    spans[1].style.opacity = '';
    spans[2].style.transform = '';
  });
});

// ── SCROLL REVEAL ───────────────────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px'
});

document.querySelectorAll('.reveal').forEach(el => {
  revealObserver.observe(el);
});

// Stagger children for grids
function staggerChildren(selector, parentSelector, baseDelay = 0.1) {
  document.querySelectorAll(parentSelector).forEach(parent => {
    const children = parent.querySelectorAll(selector);
    children.forEach((child, i) => {
      child.style.transitionDelay = `${baseDelay * i}s`;
    });
  });
}

staggerChildren('.service-card', '.services__grid');
staggerChildren('.why-card', '.why__grid');
staggerChildren('.review-card', '.reviews__grid');
staggerChildren('.result-card', '.results__grid');

// ── APPOINTMENT FORM ────────────────────────
function handleFormSubmit() {
  const inputs = document.querySelectorAll('.appt-form__input');
  let allFilled = true;

  inputs.forEach(input => {
    if (!input.value.trim()) {
      allFilled = false;
      input.style.borderColor = '#e05252';
      input.addEventListener('input', () => {
        input.style.borderColor = '';
      }, { once: true });
    }
  });

  if (!allFilled) return;

  const btn = document.getElementById('formBtn');
  const success = document.getElementById('formSuccess');

  btn.disabled = true;
  btn.textContent = 'Sending…';
  btn.style.opacity = '0.7';

  // Simulate send (no backend)
  setTimeout(() => {
    btn.style.display = 'none';
    success.classList.add('show');

    // Reset after 5 seconds
    setTimeout(() => {
      inputs.forEach(inp => inp.value = '');
      btn.style.display = 'flex';
      btn.disabled = false;
      btn.innerHTML = `Request Appointment <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`;
      btn.style.opacity = '1';
      success.classList.remove('show');
    }, 5000);
  }, 1200);
}

// ── SMOOTH SCROLL for anchor links ─────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const href = this.getAttribute('href');
    if (href === '#') return;
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      const offset = 80;
      const targetY = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: targetY, behavior: 'smooth' });
    }
  });
});

// ── HERO STATS COUNTER ───────────────────────
function animateCounter(el, target, suffix = '', duration = 1500) {
  let start = 0;
  const increment = target / (duration / 16);
  const timer = setInterval(() => {
    start += increment;
    if (start >= target) {
      start = target;
      clearInterval(timer);
    }
    el.textContent = Math.floor(start).toLocaleString() + suffix;
  }, 16);
}

// Trigger counters when hero stats are visible
const statsEl = document.querySelector('.hero__stats');
if (statsEl) {
  const statsObserver = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      const nums = statsEl.querySelectorAll('.hero__stat-num');
      // Animate: 5000+, 4.8★, 10+
      if (nums[0]) {
        let n = 0;
        const iv = setInterval(() => {
          n += 80;
          if (n >= 5000) { n = 5000; clearInterval(iv); }
          nums[0].innerHTML = `${n.toLocaleString()}<sup>+</sup>`;
        }, 16);
      }
      statsObserver.disconnect();
    }
  }, { threshold: 0.5 });
  statsObserver.observe(statsEl);
}

// ── ACTIVE NAV LINK ON SCROLL ───────────────
const sections = document.querySelectorAll('section[id]');
const navAnchors = document.querySelectorAll('.nav__links a');

window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(section => {
    const sTop = section.offsetTop - 120;
    if (window.scrollY >= sTop) current = section.getAttribute('id');
  });
  navAnchors.forEach(a => {
    a.style.color = '';
    if (a.getAttribute('href') === `#${current}`) {
      a.style.color = 'var(--teal)';
    }
  });
}, { passive: true });
